package lib.DAO;

public class DAOException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5071563566163148461L;

	public DAOException(String message) {
		super(message);
	}
}
